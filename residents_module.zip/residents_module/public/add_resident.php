<?php
include '../config/db.php'; // Database connection

// Form handling
$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize inputs
    $full_name = trim($_POST["full_name"]);
    $dob = $_POST["dob"];
    $nic = trim($_POST["nic"]);
    $address = trim($_POST["address"]);
    $phone = trim($_POST["phone"]);
    $email = trim($_POST["email"]);
    $occupation = trim($_POST["occupation"]);
    $gender = $_POST["gender"];

    // Basic validation
    if (empty($full_name) || empty($dob) || empty($nic) || empty($address) || empty($phone) || empty($email) || empty($gender)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Insert into database
        $stmt = $conn->prepare("INSERT INTO residents (full_name, dob, nic, address, phone, email, occupation, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $full_name, $dob, $nic, $address, $phone, $email, $occupation, $gender);

        if ($stmt->execute()) {
            $success = "Resident added successfully!";
        } else {
            $error = "Error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Resident</title>
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Optional styling -->
</head>
<body>
    <h2>Add New Resident</h2>

    <?php if ($success) echo "<p style='color:green;'>$success</p>"; ?>
    <?php if ($error) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST" action="">
        <label>Full Name:</label><br>
        <input type="text" name="full_name" required><br><br>

        <label>Date of Birth:</label><br>
        <input type="date" name="dob" required><br><br>

        <label>NIC:</label><br>
        <input type="text" name="nic" required maxlength="12"><br><br>

        <label>Address:</label><br>
        <textarea name="address" required></textarea><br><br>

        <label>Phone:</label><br>
        <input type="text" name="phone" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Occupation:</label><br>
        <input type="text" name="occupation"><br><br>

        <label>Gender:</label><br>
        <select name="gender" required>
            <option value="select">-Select-</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select><br><br>

        <input type="submit" value="Add Resident">
    </form>
</body>
</html>
