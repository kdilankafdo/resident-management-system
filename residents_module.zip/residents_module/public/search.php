<?php
include '../config/db.php';

$results = [];
$search = "";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['query'])) {
    $search = trim($_GET['query']);
    
    $sql = "SELECT * FROM residents 
            WHERE full_name LIKE ? 
               OR nic LIKE ? 
               OR address LIKE ?";

    $stmt = $conn->prepare($sql);
    $like = "%" . $search . "%";
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $results = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Search Residents</title>
</head>
<body>
    <h2>Search Residents</h2>

    <form method="GET" action="">
        <input type="text" name="query" placeholder="Search by Name, NIC or Address" required value="<?= htmlspecialchars($search) ?>">
        <input type="submit" value="Search">
    </form>

    <?php if (!empty($search)) : ?>
        <h3>Search Results for: "<?= htmlspecialchars($search) ?>"</h3>

        <?php if ($results->num_rows > 0): ?>
            <table border="1" cellpadding="10">
                <tr>
                    <th>Full Name</th>
                    <th>NIC</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Actions</th>
                </tr>
                <?php while($row = $results->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['full_name'] ?></td>
                        <td><?= $row['nic'] ?></td>
                        <td><?= $row['address'] ?></td>
                        <td><?= $row['phone'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['gender'] ?></td>
                        <td>
                            <a href="update.php?id=<?= $row['id'] ?>">Edit</a> |
                            <a href="delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this resident?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>No residents found.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>
