<?php
include '../config/db.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    die("Invalid ID.");
}

// Step 1: Confirm resident exists
$stmt = $conn->prepare("SELECT * FROM residents WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Resident not found.");
}

$resident = $result->fetch_assoc();

// Step 2: Handle confirmation
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["confirm"]) && $_POST["confirm"] === "yes") {
        $stmt = $conn->prepare("DELETE FROM residents WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            echo "<p style='color:green;'>Resident deleted successfully.</p>";
            echo "<a href='search.php'>Back to Search</a>";
            exit;
        } else {
            echo "<p style='color:red;'>Error deleting record.</p>";
        }
    } else {
        header("Location: search.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Resident</title>
</head>
<body>
    <h2>Are you sure you want to delete this resident?</h2>

    <p><strong>Full Name:</strong> <?= $resident['full_name'] ?></p>
    <p><strong>NIC:</strong> <?= $resident['nic'] ?></p>
    <p><strong>Address:</strong> <?= $resident['address'] ?></p>

    <form method="POST">
        <input type="hidden" name="confirm" value="yes">
        <button type="submit">Yes, Delete</button>
        <a href="search.php">Cancel</a>
    </form>
</body>
</html>
