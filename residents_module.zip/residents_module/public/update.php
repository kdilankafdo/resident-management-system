<?php
include '../config/db.php';

$id = $_GET['id'] ?? null;
$error = "";
$success = "";

// Step 1: Fetch existing data
if ($id) {
    $stmt = $conn->prepare("SELECT * FROM residents WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resident = $stmt->get_result()->fetch_assoc();

    if (!$resident) {
        die("Resident not found.");
    }
} else {
    die("Invalid ID.");
}

// Step 2: Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = trim($_POST["full_name"]);
    $dob = $_POST["dob"];
    $nic = trim($_POST["nic"]);
    $address = trim($_POST["address"]);
    $phone = trim($_POST["phone"]);
    $email = trim($_POST["email"]);
    $occupation = trim($_POST["occupation"]);
    $gender = $_POST["gender"];

    if (empty($full_name) || empty($dob) || empty($nic) || empty($address) || empty($phone) || empty($email) || empty($gender)) {
        $error = "Please fill in all required fields.";
    } else {
        $stmt = $conn->prepare("UPDATE residents SET full_name=?, dob=?, nic=?, address=?, phone=?, email=?, occupation=?, gender=? WHERE id=?");
        $stmt->bind_param("ssssssssi", $full_name, $dob, $nic, $address, $phone, $email, $occupation, $gender, $id);

        if ($stmt->execute()) {
            $success = "Resident updated successfully!";
            // Reload the updated values
            $resident = [
                'full_name' => $full_name,
                'dob' => $dob,
                'nic' => $nic,
                'address' => $address,
                'phone' => $phone,
                'email' => $email,
                'occupation' => $occupation,
                'gender' => $gender
            ];
        } else {
            $error = "Error updating resident.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Resident</title>
</head>
<body>
    <h2>Update Resident</h2>

    <?php if ($success) echo "<p style='color:green;'>$success</p>"; ?>
    <?php if ($error) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST">
        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?= $resident['full_name'] ?>" required><br><br>

        <label>Date of Birth:</label><br>
        <input type="date" name="dob" value="<?= $resident['dob'] ?>" required><br><br>

        <label>NIC:</label><br>
        <input type="text" name="nic" value="<?= $resident['nic'] ?>" required><br><br>

        <label>Address:</label><br>
        <textarea name="address" required><?= $resident['address'] ?></textarea><br><br>

        <label>Phone:</label><br>
        <input type="text" name="phone" value="<?= $resident['phone'] ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= $resident['email'] ?>" required><br><br>

        <label>Occupation:</label><br>
        <input type="text" name="occupation" value="<?= $resident['occupation'] ?>"><br><br>

        <label>Gender:</label><br>
        <select name="gender" required>
            <option value="Male" <?= $resident['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
            <option value="Female" <?= $resident['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
            <option value="Other" <?= $resident['gender'] == 'Other' ? 'selected' : '' ?>>Other</option>
        </select><br><br>

        <input type="submit" value="Update">
    </form>
</body>
</html>
