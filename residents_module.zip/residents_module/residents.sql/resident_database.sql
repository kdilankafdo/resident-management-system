-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2025 at 07:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resident_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

CREATE TABLE `residents` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `nic` varchar(12) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `occupation` varchar(50) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `registered_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `residents`
--

INSERT INTO `residents` (`id`, `full_name`, `dob`, `nic`, `address`, `phone`, `email`, `occupation`, `gender`, `registered_date`) VALUES
(1, 'Kamal Perera', '1992-04-05', '921234567V', '123 Main Street, Colombo', '0771234567', 'kamal@example.com', 'Teacher', 'Male', '2025-04-11 04:20:50'),
(2, 'Nimali Silva', '1989-12-20', '891234567V', '456 Lake Road, Kandy', '0719876543', 'nimali@example.com', 'Nurse', 'Female', '2025-04-11 04:20:50'),
(3, 'Tharindu Fernando', '1995-08-10', '951112345V', '89 Temple Road, Galle', '0761122334', 'tharindu@example.com', 'Software Engineer', 'Male', '2025-04-11 04:20:50'),
(4, 'Ishara Wickramasinghe', '1997-01-15', '973456789V', '77 Hilltop, Nuwara Eliya', '0759988776', 'ishara@example.com', 'Accountant', 'Female', '2025-04-11 04:20:50'),
(5, 'Sajith Liyanage', '1990-07-22', '901122334V', '12 Beach Side, Negombo', '0772233445', 'sajith@example.com', 'Mechanic', 'Male', '2025-04-11 04:20:50'),
(6, 'Anushka Dissanayake', '1993-11-05', '931112233V', '34 Garden Lane, Kurunegala', '0783344556', 'anushka@example.com', 'Pharmacist', 'Female', '2025-04-11 04:20:50'),
(7, 'Ruwan Hettiarachchi', '1988-02-18', '881234567V', '56 Lotus Rd, Matara', '0701234567', 'ruwan@example.com', 'Farmer', 'Male', '2025-04-11 04:20:50'),
(8, 'Dinesha Jayasinghe', '1999-09-30', '992233445V', '90 Rose Hill, Jaffna', '0723344556', 'dinesha@example.com', 'Bank Clerk', 'Female', '2025-04-11 04:20:50'),
(9, 'Shanilka Karunaratne', '1996-06-12', '961122334V', '10 Green Street, Badulla', '0744455667', 'shanilka@example.com', 'Student', 'Other', '2025-04-11 04:20:50'),
(10, 'Harsha Rajapaksha', '1994-03-27', '941234567V', '11 Sunset Rd, Anuradhapura', '0715566778', 'harsha@example.com', 'Driver', 'Male', '2025-04-11 04:20:50'),
(12, 'Dilanka Fernando', '2002-02-16', '200204703342', '125,Lunuwila', '0773054320', 'kdilankafdo@gmail.com', 'Student', 'Male', '2025-04-11 05:10:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nic` (`nic`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `residents`
--
ALTER TABLE `residents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
